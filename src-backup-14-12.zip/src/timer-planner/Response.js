export var Respons = [
    {
        'startTime' : '30',
        'desc'      : 'run',
        'resetTime' : '2600'


    },
    {
        'startTime' : '1',
        'desc'      : 'study',
        'resetTime' : '2400'


    },
    {
        'startTime' : '45',
        'desc'      : 'Meditation',
        'resetTime' : '3000'


    },
]